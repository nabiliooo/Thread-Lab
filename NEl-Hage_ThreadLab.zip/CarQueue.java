import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class CarQueue {
	private Queue<Integer> queue;
	private Random rand = new Random();
	
	public CarQueue() {
		queue = new LinkedList<Integer>();

		queue.add(rand.nextInt(4));
		queue.add(rand.nextInt(4));
		queue.add(rand.nextInt(4));
		queue.add(rand.nextInt(4));
		queue.add(rand.nextInt(4));
		queue.add(rand.nextInt(4));
	}
	
	public void addToQueue(){
		class addRunnable implements Runnable{
			public void run(){
				try{
					while(true){
						queue.add(rand.nextInt(4));
						Thread.sleep(100);
					}
				} catch (InterruptedException e){
					e.printStackTrace();
				}
			}
		}
		addRunnable run = new addRunnable();
		Thread thread = new Thread(run);
		thread.start();
	}

	public int deleteQueue(){
		return this.queue.remove();
	}

}